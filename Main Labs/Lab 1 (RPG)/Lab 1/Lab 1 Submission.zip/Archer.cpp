#include "Archer.h"

//Constructors
Archer::Archer(std::string sName, int iMaxHitPoints, int iStrength, int iSpeed, int iMagic) {
	this->m_name = sName;
	this->m_maximumHitPoints = iMaxHitPoints;
	this->m_currentHitPoints = m_maximumHitPoints;
	this->m_strength = iStrength;
	this->m_speed = iSpeed;
	this->m_magic = iMagic;
	this->m_currentSpeed = m_speed;
}
/*
*	toString()
*
*	Prints out fighters information in a formatted manner.  The output of this method is independent
*	of figher type and should be of the following format:
*
*	<name> <current HP> <maximum HP> <strength> <speed> <magic>
*
*/
std::string Archer::toString() {
	std::ostringstream out;
	out << m_name << " " << m_currentHitPoints << " " << m_maximumHitPoints << " " <<
		m_strength << " " << m_currentSpeed << " " << m_magic;
	return out.str();
}
/*
*	getDamage()
*
*	Returns the amount of damage a fighter will deal.
*
*	Archer:
*	This value is equal to the Archer's speed.
*/
int Archer::getDamage() {
	int iDamage = m_currentSpeed;
	return iDamage;
}
/*
*	reset()
*
*	Restores a fighter's current hit points to its maximum hit points.
*
*	Archer:
*	Also resets an Archer's current speed to its original value.
*/
void Archer::reset() {
	Fighter::reset();
	m_currentSpeed = m_speed;
}
/*
*	useAbility()
*
*	Attempts to perform a special ability based on the type of fighter.  The
*	fighter will attempt to use this special ability just prior to attacking
*	every turn.
*
*	Archer: Quickstep
*	Increases the Archer's speed by one point each time the ability is used.
*	This bonus lasts until the reset() method is used.
*	This ability always works; there is no maximum bonus speed.
*
*	Return true if the ability was used; false otherwise.
*/
bool Archer::useAbility() {
	int iOriginalCurrentSpeed = m_currentSpeed;
	m_currentSpeed += 1;

	if (m_currentSpeed != iOriginalCurrentSpeed) {
		return true;
	}
	else {
		return false;
	}
}